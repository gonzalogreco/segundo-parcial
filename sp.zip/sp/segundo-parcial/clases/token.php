<?php
    //require "vendor/autoload.php";
    namespace Token;

    use \Firebase\JWT\JWT;

class Token {

    private static $key = "segundoparcial";

    static function ValidarToken(){
        try {
            $token = isset($_SERVER['HTTP_TOKEN']) ? $_SERVER['HTTP_TOKEN'] : null;
            $decode = JWT::decode($token, self::$key, array('HS256'));
            return $decode;
        } catch (\Throwable $th) {
            return false;
        }
    }

    static function CrearToken($email, $nombre, $tipo, $id){
        $payload = array(
            "email" => $email,
            "nombre" => $nombre,
            "tipo" => $tipo,
            "id" => $id,
        );

        $token = JWT::encode($payload, self::$key);

        return $token;
    }

    static function DevolverId(){
        $decode = JWT::decode($_SERVER['HTTP_TOKEN'], self::$key, array('HS256'));
        return $decode->id;
    }
}

?>