<?php
require __DIR__.'/vendor/autoload.php';

use \Firebase\JWT\JWT;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Slim\Factory\AppFactory;
use Slim\Routing\RouteCollectorProxy;
use App\Controllers\UsuarioController;
use App\Controllers\MateriaController;
use App\Controllers\InscripcionController;
use Config\Database;
use App\Middlewares\JsonMiddleware;
use App\Middlewares\AuthMiddleware;
use App\Middlewares\AdminMiddleware;
use App\Middlewares\AlumnoMiddleware;
use App\Middlewares\ProfAdminMiddleware;

$app = AppFactory::create();
$app->setBasePath('/sp/segundo-parcial');
new Database;

$app->post('/users', UsuarioController::class.":crear");
$app->post('/login', UsuarioController::class.":login");

$app->group('/materia', function (RouteCollectorProxy $group) {
    $group->get('[/]', MateriaController::class.":getAll");

    $group->post('[/]', MateriaController::class.":post")->add(new AdminMiddleware);
})->add(new AuthMiddleware);

$app->group('/inscripcion', function (RouteCollectorProxy $group) {
    $group->get('/{id}[/]', InscripcionController::class.":get")->add(new ProfAdminMiddleware);

    $group->post('/{id}[/]', InscripcionController::class.":post")->add(new AlumnoMiddleware);
})->add(new AuthMiddleware);

$app->add(new JsonMiddleware);

$app->run();
?>