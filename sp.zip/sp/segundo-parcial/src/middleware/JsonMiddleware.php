<?php

namespace App\Middlewares;

class JsonMiddleware{
    public function __invoke($request, $handler){
        $response = $handler->handle($request);

        return $response->withHeader('Content-type', 'application/json');
    }
}
?>