<?php

namespace App\Controllers;

use App\Models\Materia;
use Token\Token;

class MateriaController{

    public function getAll($request, $response, $args) {
        $data = Materia::get();
        $response->getBody()->write(json_encode($data));

        return $response->withStatus(200);
    }

    public function post($request, $response, $args) {
        $materia = new Materia;
        $materia->materia = $request->getParsedBody()['materia'];
        $materia->cupos = $request->getParsedBody()['cupos'];
        $materia->cuatrimestre = $request->getParsedBody()['cuatrimestre'];

        $data = $materia->save();

        $response->getBody()->write(json_encode($data));

        return $response->withStatus(200);
    }
}

?>