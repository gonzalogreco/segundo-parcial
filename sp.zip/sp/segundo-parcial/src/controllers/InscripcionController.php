<?php

namespace App\Controllers;

use App\Models\Materia;
use App\Models\Inscripcion;
use Token\Token;

class InscripcionController{
    public function get($request, $response, $args) {
        $data = Inscripcion::find($args['id']);
        $response->getBody()->write(json_encode($data));
        
        return $response->withStatus(200);
    }

    public function post($request, $response, $args) {
        $idMateria = $args['id'];
        $materia = Materia::find($idMateria);

        if ($materia == null || $materia->cupos <= 0) {
            $data = array("Error" => "No se pudo anotar");
            $response->getBody()->write(json_encode($data));
    
            return $response->withStatus(400);
        }

        $inscripcion = new Inscripcion;
        $inscripcion->idAlumno = Token::DevolverId();
        $inscripcion->idMateria = $idMateria;

        $data = $inscripcion->save();

        $materia->cupos = $materia->cupos -1;
        $materia->save();

        $response->getBody()->write(json_encode($data));

        return $response->withStatus(200);
    }
}

?>