<?php

namespace App\Controllers;

use App\Models\Usuario;
use Token\Token;

class UsuarioController{
    public function get($request, $response, $args) {
        $data = Usuario::find($args['id']);
        $response->getBody()->write(json_encode($data));
        
        return $response->withStatus(200);
    }

    public function getAll($request, $response, $args) {
        $data = Usuario::get();
        $response->getBody()->write(json_encode($data));

        return $response->withStatus(200);
    }

    public function post($request, $response, $args) {
        $usuario = new Usuario;
        $usuario->nombre = $request->getParsedBody()['nombre'];
        $usuario->apellido = $request->getParsedBody()['apellido'];
        $usuario->mail = $request->getParsedBody()['mail'];

        $data = $usuario->save();

        $response->getBody()->write(json_encode($data));

        return $response->withStatus(200);
    }

    public function put($request, $response, $args) {
        $usuario = Usuario::find($args['id']);
 
        $usuario->nombre = $request->getParsedBody()['nombre'];
        $usuario->apellido = $request->getParsedBody()['apellido'];
        $usuario->mail = $request->getParsedBody()['mail'];

        $data = $usuario->save();

        $response->getBody()->write(json_encode($data));

        return $response->withStatus(200);
    }

    public function delete($request, $response, $args) {
        $usuario = Usuario::find($args['id']);
        $data = $usuario->delete();
        
        return $response->withStatus(200);
    }

    public function crear($request, $response, $args) {
        $usuario = new Usuario;
        $usuario->nombre = $request->getParsedBody()['nombre'];
        $usuario->clave = $request->getParsedBody()['clave'];
        $usuario->email = $request->getParsedBody()['email'];
        $usuario->tipo = $request->getParsedBody()['tipo'];

        if (!UsuarioController::validarNombre($usuario->nombre)) {
            $data = array("Error" => "El nombre no es valido");
            $response->getBody()->write(json_encode($data));

            return $response->withStatus(400);
        }

        if (!UsuarioController::validarEmail($usuario->email)) {
            $data = array("Error" => "El email no es valido");
            $response->getBody()->write(json_encode($data));

            return $response->withStatus(400);
        }

        if (!UsuarioController::validarClave($usuario->clave)) {
            $data = array("Error" => "La clave no es valido");
            $response->getBody()->write(json_encode($data));

            return $response->withStatus(400);
        }

        if (!UsuarioController::validarTipo($usuario->tipo)) {
            $data = array("Error" => "El tipo no es valido");
            $response->getBody()->write(json_encode($data));

            return $response->withStatus(400);
        }

        $data = $usuario->save();

        $response->getBody()->write(json_encode($data));

        return $response->withStatus(200);
    }

    static function validarNombre($nombre){
        if (Usuario::where("nombre", $nombre)->first() != null || $nombre != trim($nombre)) {
            return false;
        }

        return true;
    }

    static function validarEmail($email){
        if (Usuario::where("email", $email)->first() != null) {
            return false;
        }

        return true;
    }

    static function validarClave($clave){
        if (strlen($clave) < 4) {
            return false;
        }

        return true;
    }

    static function validarTipo($tipo){
        if ($tipo != "alumno" && $tipo != "admin" && $tipo != "profesor") {
            return false;
        }

        return true;
    }

    public function login($request, $response, $args) {
        $nombre = isset($request->getParsedBody()['nombre']) ? $request->getParsedBody()['nombre'] : null;
        $clave = $request->getParsedBody()['clave'];
        $email = isset($request->getParsedBody()['email']) ? $request->getParsedBody()['email'] : null;

        if ($nombre != null) {
            $usuario = Usuario::where("nombre", $nombre)->first();

            if ($usuario->clave == $clave) {
                $token = Token::CrearToken($email, $nombre, $tipo);
                $response->getBody()->write(json_encode($token));

                return $response->withStatus(200);
            }
        }

        if ($email != null) {
            $usuario = Usuario::where("email", $email)->first();

            if ($usuario->clave == $clave) {
                $token = Token::CrearToken($email, $nombre, $usuario->tipo, $usuario->id);
                $response->getBody()->write(json_encode($token));

                return $response->withStatus(200);
            }
        }

        $data = array("Error" => "No se pudo logear");
        $response->getBody()->write(json_encode($data));

        return $response->withStatus(400);
    }
}

?>